package com.learning;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReadtoexcelWriteinmysqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReadtoexcelWriteinmysqlApplication.class, args);
	}

}
