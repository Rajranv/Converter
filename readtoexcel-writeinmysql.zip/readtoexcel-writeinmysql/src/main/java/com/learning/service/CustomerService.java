package com.learning.service;

import java.io.IOException;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.learning.entity.CustomerEntity;
import com.learning.repository.CustomerRepo;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class CustomerService {
	
	@Autowired 
	private CustomerRepo customerRepo;
	
	public void saveCustomerToDatabase(MultipartFile file) {
		if(ExcelUpload.isValidExcelFile(file)) {
			try {
				List<CustomerEntity> customers = ExcelUpload.getCustomerDataFromExcel(file.getInputStream());
				this.customerRepo.saveAll(customers);
			} catch (IOException e) {
				throw new IllegalArgumentException("the file in not valid");
			}
			
		}
	}
	
	public List<CustomerEntity> getCustomers(){
		return customerRepo.findAll();
	}

}
