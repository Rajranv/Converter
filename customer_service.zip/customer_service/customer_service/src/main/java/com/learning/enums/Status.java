package com.learning.enums;

public enum Status {
	
	SUCCESS , FAILED;

}
