package com.learning.globalExceptions;

public class SupplierResponseException extends RuntimeException {

	public SupplierResponseException(String message) {
		super(message);
		
	}
}
