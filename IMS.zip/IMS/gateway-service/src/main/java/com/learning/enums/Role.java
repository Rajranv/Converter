package com.learning.enums;

public enum Role {
	SUPPLIER,CUSTOMER

}
