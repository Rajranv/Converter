package com.learning.enums;

public enum PaymentMode {

	CASH , NETBANKING ,CARD
}
