package com.learning.enums;

public enum ProductStatus {
	IN_STOCK, OUT_OF_STOCK
}
