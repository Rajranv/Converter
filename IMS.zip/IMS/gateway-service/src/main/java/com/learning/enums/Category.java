package com.learning.enums;

public enum Category {
	ELECTRONICS, CLOTHING, FURNITURE, APPLIANCES, FOOTWARE, MISCELLANEOUS
}
