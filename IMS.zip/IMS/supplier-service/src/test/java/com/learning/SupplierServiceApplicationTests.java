package com.learning;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SupplierServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
