package com.multiple.datasource.enums;

public enum PaymentMode {
	CASH, CARD, NET_BANKING;
	   
}
