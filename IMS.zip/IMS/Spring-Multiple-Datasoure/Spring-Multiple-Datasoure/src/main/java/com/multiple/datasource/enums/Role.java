package com.multiple.datasource.enums;

public enum Role {
    
	CUSTOMER,SUPPLIER;

}
