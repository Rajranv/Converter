package com.learning.demo.enums;

public enum Status {
	SUCCESS,FAILED

}
