package phonebook;

public class MainMethod {
	 public static void main(String[] args) {
	        Phonebook phonebook = new Phonebook();

	        // Add contacts
	        phonebook.addContact("Ranveer Raj", "123-456-7890", "ranveer@email.com");
	        phonebook.addContact("Rishbh", "987-654-3210","rishbh@gmail.com");
	        phonebook.addContact("Ravi", "555-555-5555","ravi@gamil.com");

	        // Display all contacts
	        System.out.println("All Contacts:");
	        phonebook.displayContacts();

	        // Search for a contact
	        System.out.println("\nSearch for a contact:");
	        phonebook.searchContact("Ranveer Raj");

	        // Delete a contact
	        System.out.println("\nDelete a contact:");
	        phonebook.deleteContact("Ranveer Raj");
	        phonebook.displayContacts();
	    }

}

class Contact {
    String name;
    String phoneNumber;
    String emailId;
    Contact next;

    public Contact(String name, String phoneNumber,String emailId) {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.emailId = emailId;
        this.next = null;
    }
}

class Phonebook {
    private Contact head;

    public Phonebook() {
        this.head = null;
    }

    public void addContact(String name, String phoneNumber,String emailID) {
        Contact contact = new Contact(name,phoneNumber,emailID);
         if(head == null) {
        	 head = contact;
         }else {
        	 Contact current = head;
        	 while(current.next != null){
        		 current = current.next;
        	 }
        	 current.next = contact;
         }
    }

    public void deleteContact(String name) {
        if (head == null) {
            System.out.println("Phonebook is empty.");
            return;
        }

        if (head.name.equals(name)) {
            head = head.next;
            return;
        }

        Contact current = head;
        while (current.next != null) {
            if (current.next.name.equals(name)) {
                current.next = current.next.next;
                return;
            }
            current = current.next;
        }

        System.out.println("Contact '" + name + "' not found.");
    }

    public void searchContact(String name) {
        Contact current = head;
        while (current != null) {
            if (current.name.equals(name)) {
                System.out.println("Name: " + current.name + ", Phone Number: " + current.phoneNumber +", Email Id: "+current.emailId);
                return;
            }
            current = current.next;
        }
        System.out.println("Contact '" + name + "' not found.");
    }

    public void displayContacts() {
        if (head == null) {
            System.out.println("Phonebook is empty.");
            return;
        }

        Contact current = head;
        while (current != null) {
            System.out.println("Name: " + current.name + ", Phone Number: " + current.phoneNumber + ", Email id: "+ current.emailId);
            current = current.next;
        }
    }

   
}
