package com.learning.demo.enums;

public enum Role {
	SUPPLIER,CUSTOMER

}
